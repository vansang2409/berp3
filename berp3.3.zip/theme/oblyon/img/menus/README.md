
Tutorial to create a new image for menu:

1) First find an image.
2) With Gimp, open image and check there is a alpha channel. If not add one.
3) Convert image into back and white.
4) Use the degrade tool with option:
* Erase color
* Opacity: 50 +/-
* Offset: 0
* Shape: Linear
Il est possible aussi d'augmenter la transparence globale depuis le calque.
