<?php
if (!defined('ISLOADEDBYSTEELSHEET')) {
	die('Must be call by steelsheet');
}

include dol_buildpath($path.'/theme/eldy/progress.inc.php', 0); // actually md use same style as eldy theme

?>
/* <style type="text/css" > */
